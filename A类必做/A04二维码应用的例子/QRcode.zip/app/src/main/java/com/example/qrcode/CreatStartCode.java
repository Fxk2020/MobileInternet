package com.example.qrcode;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.yzq.zxinglibrary.encode.CodeCreator;

public class CreatStartCode extends AppCompatActivity {

    private Button mButton;
    private EditText mEditText;
    private ImageView mImageView;
    private Bitmap bitmap;

    private static final int COMPLETED=0;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == COMPLETED) {
                mImageView.setImageBitmap(bitmap);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creat_start_code);
        mButton = findViewById(R.id.bt_c);
        mEditText = findViewById(R.id.et_c);
        mImageView = findViewById(R.id.iv_c);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value = mEditText.getText().toString();
                if (value==null)
                    return;
                bitmap = CodeCreator.createQRCode(value,200,200,null);
                Message msg = new Message();
                msg.what = COMPLETED;
                handler.sendMessage(msg);
            }
        });
    }
}
