package com.example.qrcode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.yzq.zxinglibrary.android.CaptureActivity;
import com.yzq.zxinglibrary.common.Constant;
import com.yzq.zxinglibrary.encode.CodeCreator;


public class MainActivity extends AppCompatActivity {

    private Button mButton1;
    private Button mButton2;
    private Button mButton3;
    private TextView mTextView;
    private int REQUEST_CODE_SCAN = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mButton1 = findViewById(R.id.bt_1);
        mButton2 = findViewById(R.id.bt_2);
        mButton3 = findViewById(R.id.bt_3);
        mTextView = findViewById(R.id.tv_1);
        setListeners();
    }
    private void setListeners(){
        OnClick onclick = new OnClick();
        mButton1.setOnClickListener(onclick);
        mButton2.setOnClickListener(onclick);
        mButton3.setOnClickListener(onclick);
    }
    private  class OnClick implements View.OnClickListener{
        public void onClick(View v){
            Intent intent = null;
            switch (v.getId()){
                case R.id.bt_1:
                    intent = new Intent(MainActivity.this,CaptureActivity.class);//跳转到TextViewActivity
                    startActivityForResult(intent,REQUEST_CODE_SCAN);
                    break;
                case R.id.bt_2:
                    intent = new Intent(MainActivity.this,CreatStartCode.class);//跳转到ButtonActivity
                    startActivity(intent);
                    break;
                case R.id.bt_3:
                    intent = new Intent(MainActivity.this,ReadProcessCode.class);//跳转到EditTextActivity
                    startActivity(intent);
                    break;
            }
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 扫描二维码/条码回传
        if (requestCode == REQUEST_CODE_SCAN && resultCode == RESULT_OK) {
            if (data != null) {

                String content = data.getStringExtra(Constant.CODED_CONTENT);
                mTextView.setText("二维码最终结果为：" + content);
            }
        }
    }

}
