package com.example.qrcode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.yzq.zxinglibrary.android.CaptureActivity;
import com.yzq.zxinglibrary.common.Constant;
import com.yzq.zxinglibrary.encode.CodeCreator;

public class ReadProcessCode extends AppCompatActivity {

    private Button mButton;
    private EditText mEditText;
    private ImageView mImageView;
    private int REQUEST_CODE_SCAN = 1;
    private Bitmap bitmap;


    private static final int COMPLETED=0;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == COMPLETED) {
                mImageView.setImageBitmap(bitmap);
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_process_code);
        mButton = findViewById(R.id.bt_r);
        mEditText = findViewById(R.id.et_r);
        mImageView = findViewById(R.id.iv_r);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mEditText.getText().toString()==null){

                }else{
                Intent intent = new Intent(ReadProcessCode.this, CaptureActivity.class);
                startActivityForResult(intent,REQUEST_CODE_SCAN);
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 扫描二维码/条码回传
        if (requestCode == REQUEST_CODE_SCAN && resultCode == RESULT_OK) {
            if (data != null) {
                String content = data.getStringExtra(Constant.CODED_CONTENT);
                String contents[] = content.split("=");
                String addvalue = mEditText.getText().toString();
                int value;
                if(contents.length>1)
                    value = Integer.parseInt(contents[1])+Integer.parseInt(addvalue);
                else
                    value = Integer.parseInt(contents[0])+Integer.parseInt(addvalue);
                content = contents[0]+"+"+addvalue+"="+value;
                bitmap = CodeCreator.createQRCode(content,200,200,null);
                Message msg = new Message();
                msg.what = COMPLETED;
                handler.sendMessage(msg);
            }
        }
    }
}
