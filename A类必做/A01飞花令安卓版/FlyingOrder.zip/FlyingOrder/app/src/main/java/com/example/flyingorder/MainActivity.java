package com.example.flyingorder;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private EditText searchWord;
    private Button searchStart;

    //记录搜寻的结果
    private TextView search_result;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchWord=findViewById(R.id.search_word);
        searchStart=findViewById(R.id.search_start);
        search_result=findViewById(R.id.search_result);
        
        //对话框
        final AlertDialog.Builder dialog=new AlertDialog.Builder(MainActivity.this);

        searchStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Editable str = searchWord.getText();



                if (str.length()==1){


                    dialog.setTitle("提示");
                    dialog.setMessage("由于检索内容较多请稍等一会");
                    dialog.setPositiveButton("确定",new okClick());
                    dialog.create();
                    dialog.show();
//
//                    Toast.makeText(MainActivity.this,"",Toast.LENGTH_LONG).show();

                    //读取输入的关键字
                    String thisword = searchWord.getText().toString();

                    //记录收索到的结果条数
                    int sum = 1;
                    String line, ans = "";
                    String title = "";

                    try {
                        Scanner scan = new Scanner(getResources().getAssets().open("全唐诗.txt"));

                        while (scan.hasNext()){
                            line = scan.nextLine();

                            for (int i = 0; i < line.length(); i++) {
                                if (i==0&&line.charAt(i) == '◎') {//利用短路性优化程序搜索的效率
                                    title = line;
                                    break;
                                }
                                /*
                                （1）"=="是Java提供的关系运算符，主要的功能是进行数值相等判断的，如果用在了String对象上表示的是内存地址数值的比较。
                                （2）equals（）方法是由String提供的一个方法，此方法专门负责进行字符串内容的比较。
                                 */
                                if (String.valueOf(line.charAt(i)).equals(thisword)) {//indexOf如果thisword的值不存在，则返回-1 。
                                    ans += sum + ":" + line + "\n-------" + title + "\n";
                                    sum++;
                                    search_result.setText(ans);
//                                    title = "";如果换诗了题目自会改变
                                    search_result.setMovementMethod(ScrollingMovementMethod.getInstance());
                                }
                                else if (thisword == "。" || thisword == "？" || thisword == "，" || thisword == "!")
                                    break;
                                }


                                //将搜索的字体颜色变为红色
                                int k = 0;
                                SpannableStringBuilder style = new SpannableStringBuilder(ans);
                                while (k >= 0) {
                                    int l = ans.indexOf(thisword, k);
                                    int r = l + thisword.length();
                                    if (l == -1)
                                        break;
                                    k = l + 1;
                                    style.setSpan(new ForegroundColorSpan(Color.RED), l, r, Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
                                }

                                search_result.setMovementMethod(ScrollingMovementMethod.getInstance());
                                search_result.setHorizontallyScrolling(true);
                                search_result.setText(style);

                            //检索的内容超过20条退出检索系统
                            if(sum==21){
                                break;
                            }

                            }


                    } catch(IOException e){
                        ans = "抱歉，你输入的内容不在全唐诗当中！";
                        search_result.setText(ans);
                    }

                }else {
                    Toast.makeText(MainActivity.this,"飞花令的规则是只能输入一个字符",Toast.LENGTH_SHORT).show();
                }

                searchWord.setText("");//清空EditText的内容

            }
        });

}}
class okClick implements DialogInterface.OnClickListener{
    public void onClick(DialogInterface dialog,int which){
        dialog.cancel();
    }
}






