//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    shi3: "春眠不觉晓，处处闻啼鸟。\n夜来风雨声，花落知多少。\n空山不见人，但闻人语响。\n返影入深林，复照青苔上。\n红豆生南国，春来发几枝。\n 愿君多采撷，此物最相思。\n 君自故乡来，应知故乡事。\n 来日绮窗前，寒梅著花未。\n终南阴岭秀，积雪浮云端。\n林表明霁色，城中增暮寒。\n床前明月光，疑是地上霜。\n 举头望明月，低头思故乡。\n白日依山尽，黄河入海流。\n欲穷千里目，更上一层楼。\n千山鸟飞绝，万径人踪灭。\n孤舟蓑笠翁，独钓寒江雪。\n向晚意不适，驱车登古原。\n夕阳无限好，只是近黄昏。\n泠泠七弦上，静听松风寒。\n古调虽自爱，今人多不弹。\n功盖三分国，名成八阵图。\n 江流石不转，遣恨失吞吴。\n离离原上草，一岁一枯荣。\n野火烧不尽。春风吹又生。\n 远芳侵古道，晴翠接荒城。\n又送王孙去，萋萋满别情。\n慈母手中线，游子身上衣。\n临行密密缝，意恐迟迟归。\n谁言寸草心，报得三春晖。\n明月出天山，苍茫云海间。\n长风几万里，吹度玉门关。\n汉下白登道，胡窥青海湾。\n由来征战地，不见有人还。\n戍客望边色，思归多苦颜。\n高楼当此夜，叹息未应闲。\n海上生明月，天涯共此时。\n情人怨遥夜，竟夕起相思。\n灭烛怜光满，披衣觉露滋。\n 不堪盈手赠，还寝梦佳期。\n城阙辅三秦，风烟望五津。\n与君离别意，同是宦游人。\n海内存知己，天涯若比邻。\n无为在岐路，儿女共沾巾。\n国破山河在，城春草木深。\n感时花溅泪，恨别鸟惊心。\n烽火连三月，家书抵万金。\n白头搔更短，浑欲不胜簪。\n昔闻洞庭水，今上岳阳楼。\n吴楚东南坼，乾坤日夜浮。\n亲朋无一字，老病有孤舟。\n戎马关山北，凭轩涕泗流。\n中岁颇好道，晚家南山陲。\n兴来每独往，胜事空自知。\n行到水穷处，坐看云起时。\n偶然值林叟，谈笑无还期。\n葡萄美酒夜光杯，欲饮琵琶马上催。\n醉卧沙场君莫笑，古来征战几人回。\n日照香炉生紫烟，遥看瀑布挂前川。\n飞流直下三千尺，疑是银河落九天。\n故人西辞黄鹤楼，烟花三月下扬州。\n孤帆远影碧空尽，惟见长江天际流。\n朝辞白帝彩云间，千里江陵一日还。\n两岸猿声啼不住，轻舟已过万重山。\n月落乌啼霜满天，江枫渔火对愁眠。\n姑苏城外寒山寺，夜半钟声到客船。\n朱雀桥边野草花，乌衣巷口夕阳斜。\n旧时王谢堂前燕，飞入寻常百姓家。\n渭城朝雨浥轻尘，客舍青青柳色新。\n劝君更尽一杯酒，西出阳关无故人。\n秦时明月汉时关，万里长征人未还。\n但使龙城飞将在，不教胡马渡阴山。\n黄河远上白云间，一片孤城万仞山。\n羌笛何须怨杨柳，春风不度玉门关。\n碧玉妆成一树高，万条垂下绿丝绦。\n不知细叶谁裁出，二月春风似剪刀。\n昔人已乘黄鹤去，此地空余黄鹤楼。\n黄鹤一去不复返，白云千载空悠悠。\n晴川历历汉阳树，芳草萋萋鹦鹉洲。\n日暮乡关何处是，烟波江上使人愁。\n黄四娘家花满蹊，千朵万朵压枝低。\n留连戏蝶时时舞，自在娇莺恰恰啼。\n清明时节雨纷纷，路上行人欲断魂。\n借问酒家何处有，牧童遥指杏花村。\n远上寒山石径斜，白云生处有人家。\n停车坐爱枫林晚，霜叶红于二月花。\n去年今日此门中，人面桃花相映红。\n人面不知何处去，桃花依旧笑春风。\n鹅，鹅，鹅，曲项向天歌。\n白毛浮绿水，红掌拨清波。\n春眠不觉晓，处处闻啼鸟。\n夜来风雨声，花落知多少。\n空山不见人，但闻人语响。\n返景入深林，复照青苔上。\n前不见古人，后不见来者。\n念天地之悠悠，独怆然而剃下。\n床前明月光，疑是地上霜。\n举头望明月，低头思故乡。\n锄禾日当午，汗滴禾下土。\n谁知盘中餐，粒粒皆辛苦。\n千山鸟飞绝，万径人踪灭。\n孤舟蓑笠翁，独钓寒江雪。\n离离原上草，一岁一枯荣。\n野火烧不尽，春风吹又生。\n白发三千丈，缘愁似个长。\n不知明镜里，何处得秋霜?\n小时不识月，呼作金玉盘。\n又疑瑶台镜，飞在碧云端。\n山中相送罢，日暮掩柴扉。\n春草年年绿，王孙归不归?\n众鸟高飞尽，孤云独去闲。\n相看两不厌，只有敬亭山。\n大漠沙如雪，燕山月似钩。\n何当金络脑，快走踏清秋。\n一望二三里，烟村四五家。\n门前六七树，八九十支花。\n好雨知时节，当春乃发生。\n随风潜入夜，润物细无声。\n耶溪采莲女，见客棹歌回。\n笑入荷花去，佯羞不出来。\n危楼高百尺，手可摘星辰。\n不敢高声语，恐惊天上人。\n小娃撑小艇，偷采白莲回。\n不解藏踪迹，浮萍一道开。\n移舟泊烟渚，日暮客愁新。\n野旷天低树，江清月近人。\n红豆生南国，春来发几枝。\n愿君多采撷，此物最相思。\n日暮苍山远，天寒白屋贫。\n柴门闻犬吠，风雪夜归人。\n松下问童子，言师采药去。\n只在此山中，云深不知处。\n慈母手中线，游子身上衣。\n临行密密缝，意恐迟迟归。\n谁言寸草心，报得三春晖。\n明日复明日，明日何其多。\n我生待明日，万事成蹉跎。",
    keystr: "请输入关键词",
    sentence: "欢迎使用飞花令小程序",
  },
  //事件处理函数
  go2s: function (e) {
  this.data.keystr = e.detail.value.keystr
    this.data.res = ""
    this.data.sentence = [{
      num:"",
      front: "",
      keyword: "",
      behind: "",
    }]
    // 检查每一行，要含有指定key的行
    var str=this.data.keystr
    if(str==""){
      this.data.res+="您的输入为空"
    }
    else{
    var reg = new RegExp(".*" + this.data.keystr + ".*")
    var lines = this.data.shi3.split("\n")
    var cti = 0
    for (var i1 in lines) {
      if (reg.test(lines[i1])) {
        cti++;
        this.data.res += cti+"."+lines[i1] + "\n"
        console.log(lines[i1])
      }
      for (var k = 0; k <= lines[i1].length - str.length; k++) {
        if (lines[i1].substring(k, k + str.length) == str) {
          var array = [{
            num:cti+".",
            front:lines[i1].substring(0, k),
            keyword: str,
            behind: lines[i1].substring(k + str.length, lines[i1].length),
          }]
          this.data.sentence = this.data.sentence.concat(array)
        }
      }
    }

    }
    this.setData({
      sentence: this.data.sentence,
      res: this.data.res
    })
  },

  
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
