package irdc.EX05_03;

import android.content.Context;
import android.content.Intent;
import android.view.View;

class c implements View.OnClickListener {
  c(EX05_03 paramEX05_03) {}
  
  public void onClick(View paramView) {
    Intent intent = new Intent();
    intent.setClass((Context)this.a, sendmsg.class);
    this.a.startActivity(intent);
  }
}


/* Location:              F:\IDM下载\压缩文件\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\irdc\EX05_03\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */