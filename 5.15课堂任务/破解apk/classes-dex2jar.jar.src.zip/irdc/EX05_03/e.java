package irdc.EX05_03;

import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

public class e {
  public static String a(String paramString1, String paramString2) {
    return a(a(b(paramString1.getBytes()), paramString2.getBytes()));
  }
  
  public static String a(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null)
      return ""; 
    StringBuffer stringBuffer = new StringBuffer(paramArrayOfbyte.length * 2);
    for (int i = 0;; i++) {
      if (i >= paramArrayOfbyte.length)
        return stringBuffer.toString(); 
      a(stringBuffer, paramArrayOfbyte[i]);
    } 
  }
  
  private static void a(StringBuffer paramStringBuffer, byte paramByte) {
    paramStringBuffer.append("0123456789ABCDEF".charAt(paramByte >> 4 & 0xF)).append("0123456789ABCDEF".charAt(paramByte & 0xF));
  }
  
  public static byte[] a(String paramString) {
    int j = paramString.length() / 2;
    byte[] arrayOfByte = new byte[j];
    for (int i = 0;; i++) {
      if (i >= j)
        return arrayOfByte; 
      arrayOfByte[i] = Integer.valueOf(paramString.substring(i * 2, i * 2 + 2), 16).byteValue();
    } 
  }
  
  private static byte[] a(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "AES");
    Cipher cipher = Cipher.getInstance("AES");
    cipher.init(1, secretKeySpec);
    return cipher.doFinal(paramArrayOfbyte2);
  }
  
  public static String b(String paramString1, String paramString2) {
    return new String(b(b(paramString1.getBytes()), a(paramString2)));
  }
  
  private static byte[] b(byte[] paramArrayOfbyte) {
    KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
    SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
    secureRandom.setSeed(paramArrayOfbyte);
    keyGenerator.init(128, secureRandom);
    return keyGenerator.generateKey().getEncoded();
  }
  
  private static byte[] b(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "AES");
    Cipher cipher = Cipher.getInstance("AES");
    cipher.init(2, secretKeySpec);
    return cipher.doFinal(paramArrayOfbyte2);
  }
}


/* Location:              F:\IDM下载\压缩文件\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\irdc\EX05_03\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */