package irdc.EX05_03;

import android.view.View;

class b implements View.OnClickListener {
  b(EX05_03 paramEX05_03) {}
  
  public void onClick(View paramView) {
    EX05_03.b(this.a).setText("");
  }
}


/* Location:              F:\IDM下载\压缩文件\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\irdc\EX05_03\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */