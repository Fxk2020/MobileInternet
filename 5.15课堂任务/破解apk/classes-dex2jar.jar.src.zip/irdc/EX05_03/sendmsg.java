package irdc.EX05_03;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;

public class sendmsg extends Activity {
  public List a() {
    ArrayList<String> arrayList = new ArrayList();
    Uri uri = Uri.parse("content://sms/inbox");
    Cursor cursor = getContentResolver().query(uri, null, null, null, null);
    uri = null;
    while (true) {
      if (!cursor.moveToNext()) {
        ((ListView)findViewById(2130968602)).setOnItemClickListener(new g(this));
        return arrayList;
      } 
      String str2 = cursor.getString(cursor.getColumnIndex("address"));
      String str1 = cursor.getString(cursor.getColumnIndexOrThrow("body"));
      if (str1.contains("IRDC")) {
        String str;
        str1 = str1.replace("IRDC", "");
        try {
          str1 = e.b("a", str1);
          str = str1;
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
        arrayList.add(String.valueOf(str2) + str);
        continue;
      } 
      arrayList.add("Number: " + str2 + " Message: " + exception);
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903044);
    ((Button)findViewById(2130968601)).setOnClickListener(new f(this));
    ((ListView)findViewById(2130968602)).setAdapter((ListAdapter)new ArrayAdapter((Context)this, 17367043, a()));
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    paramMenu.add(0, 0, 0, "关于");
    paramMenu.add(0, 1, 1, "退出");
    return super.onCreateOptionsMenu(paramMenu);
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    Intent intent;
    super.onOptionsItemSelected(paramMenuItem);
    switch (paramMenuItem.getItemId()) {
      default:
        return true;
      case 0:
        intent = new Intent();
        intent.setClass((Context)this, aboutme.class);
        startActivity(intent);
        break;
      case 1:
        break;
    } 
    finish();
  }
}


/* Location:              F:\IDM下载\压缩文件\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\irdc\EX05_03\sendmsg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */