package irdc.EX05_03;

import android.content.Context;
import android.content.Intent;
import android.view.View;

class f implements View.OnClickListener {
  f(sendmsg paramsendmsg) {}
  
  public void onClick(View paramView) {
    Intent intent = new Intent();
    intent.setClass((Context)this.a, EX05_03.class);
    this.a.startActivity(intent);
    this.a.finish();
  }
}


/* Location:              F:\IDM下载\压缩文件\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\irdc\EX05_03\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */