package irdc.EX05_03;

import android.view.View;
import android.widget.AdapterView;

class g implements AdapterView.OnItemClickListener {
  g(sendmsg paramsendmsg) {}
  
  public void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {}
}


/* Location:              F:\IDM下载\压缩文件\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\irdc\EX05_03\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */