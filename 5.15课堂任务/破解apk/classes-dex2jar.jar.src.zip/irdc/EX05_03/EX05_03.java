package irdc.EX05_03;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EX05_03 extends Activity {
  private Button a;
  
  private Button b;
  
  private EditText c;
  
  private EditText d;
  
  private String e = "IRDC";
  
  public static boolean a(String paramString) {
    boolean bool = false;
    Matcher matcher2 = Pattern.compile("^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$").matcher(paramString);
    Matcher matcher1 = Pattern.compile("^\\(?(\\d{2})\\)?[- ]?(\\d{4})[- ]?(\\d{4})$").matcher(paramString);
    if (matcher2.matches() || matcher1.matches())
      bool = true; 
    return bool;
  }
  
  public static boolean b(String paramString) {
    return (paramString.length() <= 70);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903043);
    this.c = (EditText)findViewById(2130968597);
    this.d = (EditText)findViewById(2130968598);
    this.a = (Button)findViewById(2130968599);
    this.b = (Button)findViewById(2130968600);
    this.c.setText("");
    this.d.setText("edit text here!!");
    this.c.setOnClickListener(new a(this));
    this.d.setOnClickListener(new b(this));
    this.b.setOnClickListener(new c(this));
    this.a.setOnClickListener(new d(this));
  }
}


/* Location:              F:\IDM下载\压缩文件\dex2jar-2.0\dex2jar-2.0\classes-dex2jar.jar!\irdc\EX05_03\EX05_03.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */