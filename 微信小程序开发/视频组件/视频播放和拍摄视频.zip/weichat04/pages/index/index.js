
Page({
  data: {
    videoSrc:"http://wxsnsdy.tc.qq.com/106/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045b320b0201000408",
    src2: ''
  },
  onReady: function (res) {
    this.videoContext = wx.createVideoContext('myVideo')
  },
  bindPlay: function() {
    this.videoContext.play();
    console.log("this.play");
  },
  bindPause: function() {
    this.videoContext.pause();
    console.log("this.pause");
  },
   /**
  * 打开本地视频
  */
 bindButtonTap: function() {
  var that = this;
  //拍摄视频或从手机相册中选视频
  wx.chooseVideo({
   //album 从相册选视频，camera 使用相机拍摄，默认为：['album', 'camera']
   sourceType: ['album', 'camera'],
   //拍摄视频最长拍摄时间，单位秒。最长支持60秒
   maxDuration: 60,
   //前置或者后置摄像头，默认为前后都有，即：['front', 'back']
   camera: ['front','back'],
   //接口调用成功，返回视频文件的临时文件路径，详见返回参数说明
   success: function(res) {
    console.log(res.tempFilePath)
    that.setData({
     src2: res.tempFilePath
    })
   }
  })
 },
  videoErrorCallback: function(e) {
    console.log('视频错误信息:')
    console.log(e.detail.errMsg)
  }
})