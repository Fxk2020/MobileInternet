/**常量类 */

//腾讯测试AK,请替换成自己申请的 AK
const tencentAk = 'JCXBZ-7WLWD-RPQ45-H7EM3-LXEJQ-6TBFE';

module.exports = {
  tencentAk: tencentAk
}